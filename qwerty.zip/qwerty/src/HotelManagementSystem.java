
import java.util.Scanner;

public class HotelManagementSystem {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // БЛОК 1. ИНФОРМАЦИЯ О ГОСТИНИЦЕ

        String hotelName = "Grand Hotel";
        String hotelAddress = "Astana, Kazakhstan";
        String hotelPhone = "+7 777 123 45 67";

        int totalRooms = 50;
        int availableRooms = 20;

        float hotelRating = 4.8f;
        char hotelCategory = 'A';
        boolean isOpen = true;

        System.out.println("===== ИНФОРМАЦИЯ О ГОСТИНИЦЕ =====");
        System.out.println("Название: " + hotelName);
        System.out.println("Адрес: " + hotelAddress);
        System.out.println("Телефон: " + hotelPhone);
        System.out.println("Всего номеров: " + totalRooms);
        System.out.println("Свободных номеров: " + availableRooms);
        System.out.println("Рейтинг: " + hotelRating);
        System.out.println("Категория: " + hotelCategory);
        System.out.println("Работает: " + isOpen);

        // БЛОК 2. ИНФОРМАЦИЯ О КЛИЕНТЕ

        System.out.println("\n===== РЕГИСТРАЦИЯ КЛИЕНТА =====");

        System.out.print("Введите ФИО клиента: ");
        String clientName = scanner.nextLine();

        System.out.print("Введите возраст: ");
        int clientAge = Integer.parseInt(scanner.nextLine());

        System.out.print("Введите номер документа: ");
        String clientPassport = scanner.nextLine();

        System.out.print("Введите телефон клиента: ");
        String clientPhone = scanner.nextLine();

        System.out.print("Введите баланс клиента: ");
        double clientBalance = Double.parseDouble(scanner.nextLine());

        boolean isRegistered = true;

        System.out.println("\n===== АНКЕТА КЛИЕНТА =====");
        System.out.println("ФИО: " + clientName);
        System.out.println("Возраст: " + clientAge);
        System.out.println("Документ: " + clientPassport);
        System.out.println("Телефон: " + clientPhone);
        System.out.println("Баланс: " + clientBalance + " тенге");
        System.out.println("Зарегистрирован: " + isRegistered);

        // БЛОК 3. ИНФОРМАЦИЯ О НОМЕРЕ

        System.out.println("\n===== ИНФОРМАЦИЯ О НОМЕРЕ =====");

        System.out.print("Введите номер комнаты: ");
        int roomNumber = Integer.parseInt(scanner.nextLine());

        System.out.print("Введите тип номера (Standard, Deluxe, Lux): ");
        String roomType = scanner.nextLine();

        System.out.print("Введите цену за сутки: ");
        double roomPrice = Double.parseDouble(scanner.nextLine());

        System.out.print("Введите этаж: ");
        int roomFloor = Integer.parseInt(scanner.nextLine());

        System.out.print("Есть ли Wi-Fi? (true/false): ");
        boolean hasWiFi = Boolean.parseBoolean(scanner.nextLine());

        System.out.print("Количество кроватей: ");
        int bedCount = Integer.parseInt(scanner.nextLine());

        System.out.print("Статус номера (F - свободен, B - занят): ");
        char roomStatus = scanner.nextLine().charAt(0);

        System.out.println("\nНомер комнаты: " + roomNumber);
        System.out.println("Тип: " + roomType);
        System.out.println("Цена за сутки: " + roomPrice);
        System.out.println("Этаж: " + roomFloor);
        System.out.println("Wi-Fi: " + hasWiFi);
        System.out.println("Кроватей: " + bedCount);
        System.out.println("Статус: " + roomStatus);

        // БЛОК 4. БРОНИРОВАНИЕ И ФИНАНСОВЫЕ РАСЧЕТЫ

        System.out.println("\n===== БРОНИРОВАНИЕ =====");

        System.out.print("Введите количество дней проживания: ");
        int daysOfStay = Integer.parseInt(scanner.nextLine());

        // Полная стоимость
        double totalCost = roomPrice * daysOfStay;

        System.out.print("Введите размер скидки (%): ");
        double discount = Double.parseDouble(scanner.nextLine());

        // Расчет скидки
        double discountAmount = totalCost * discount / 100;

        // Итоговая стоимость
        double finalCost = totalCost - discountAmount;

        System.out.print("Введите внесенную оплату: ");
        double paymentAmount = Double.parseDouble(scanner.nextLine());

        // Остаток задолженности
        double debt = finalCost - paymentAmount;

        if (debt < 0) {
            debt = 0;
        }

        // Идентификатор бронирования
        long bookingId = 100001L;

        // Статус бронирования
        String bookingStatus;

        if (roomStatus == 'F' || roomStatus == 'f') {
            bookingStatus = "Забронирован";
            availableRooms--;
        } else {
            bookingStatus = "Номер занят";
        }

        // БЛОК 5. ИТОГОВЫЙ ОТЧЕТ

        System.out.println("\n==================================");
        System.out.println("       ОТЧЕТ О БРОНИРОВАНИИ");
        System.out.println("==================================");

        System.out.println("ID бронирования: " + bookingId);
        System.out.println("Гостиница: " + hotelName);
        System.out.println("ФИО клиента: " + clientName);
        System.out.println("Номер комнаты: " + roomNumber);
        System.out.println("Тип номера: " + roomType);
        System.out.println("Количество дней: " + daysOfStay);

        System.out.println("----------------------------------");
        System.out.println("Цена за сутки: " + roomPrice + " тенге");
        System.out.println("Полная стоимость: " + totalCost + " тенге");
        System.out.println("Скидка: " + discount + "%");
        System.out.println("Сумма скидки: " + discountAmount + " тенге");
        System.out.println("Итоговая сумма: " + finalCost + " тенге");
        System.out.println("Внесенная оплата: " + paymentAmount + " тенге");
        System.out.println("Остаток задолженности: " + debt + " тенге");

        System.out.println("----------------------------------");
        System.out.println("Статус бронирования: " + bookingStatus);
        System.out.println("Свободных номеров осталось: " + availableRooms);
        System.out.println("==================================");

        scanner.close();
    }
}
